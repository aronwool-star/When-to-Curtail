DATA FOR THE GROUP PROJECT "When to Curtail: Hydropower and Firm Supply Security"
==================================================================================

Contents
  hydro_group_project.pdf     The assignment and individual follow-up questions.
  original_exports/           Hourly exports for Fljótsdalsstöð / Hálslón, exactly
                              as supplied by Landsvirkjun (byte-identical copies).
  original_exports/Yfirlit raða.xlsx   Supplier's overview of the series.
  original_exports/expert_note_is.txt  Supplier's note on the inflow series (Icelandic).
  wind/icewind_figure16_readings.csv   Monthly wind readings for follow-up question 1.

File format (all original_exports/*.csv)
  Encoding Latin-1; separator ';'; decimal comma (e.g. 589,19).
  Columns: Date (DD.MM.YYYY); Time (HH:MM:SS); value; then coverage and
  quality flags (Valid, Invalid, Missing, Quality, Interpolation).
  Missing values are written '---'. Keep the flags; do not treat them as values.
  Hourly rows from 01.01.2015. The last numeric values are around 02.12.2025;
  some files contain empty padding rows up to 31.12.2025. 2025 is incomplete.
  The time zone is not stated in the exports.

Series (file stem, unit, description from the supplier's overview)
  fljotsdalsstod_framleidsla                MW     Power, all generating units, hourly mean
  fljotsdalsstod_notad_vatn                 m3/s   Calculated total plant discharge
  halslon_lonhaed                           m a.s.l. Hálslón water level
  halslon_rummal                            GL     Hálslón volume, calculated from level
  halslon_natturulegt_innrennsli            m3/s   Calculated natural inflow to Hálslón
  halslon_natturulegt_innrennsli_smoothed   m3/s   Same, smoothed by the supplier
  halslon_rennsli_um_yfirfall               m3/s   Calculated Hálslón spillway discharge
  jokulsargong_rennsli                      m3/s   Measured flow in the Jökulsárgöng tunnel
                                                   (calculated replacement when frozen)

Units
  1 GL = 1 Mm3 = 10^6 m3.  A flow of q m3/s for h hours is 0.0036*q*h Mm3;
  for a 730-hour model month this is 2.628*q Mm3.

How to use the data (as set in the assignment)
  * Pooled inflow = raw Hálslón natural inflow + Jökulsárgöng tunnel flow.
    The tunnel flow stands in for the eastern intakes; this is a stated
    approximation, as the exports do not document the full routing.
  * Use the raw inflow series, not the smoothed one: its smoothing uses
    future hours and can leak information across the training/test split.
    The raw series is CALCULATED and, per the supplier's note, biased low and
    often negative in winter. Keep negative hourly values; every monthly mean
    in 2015-2025 is positive.
  * Monthly volume = mean of the available hourly values x hours in the
    month x 0.0036 (Mm3). Hourly gaps are small (worst month: 615 of 744 h).
  * Storage: 100..2270 Mm3, where the lowest 100 Mm3 is a national reserve.
    halslon_rummal can be used directly on this scale: it reads about
    2194 GL at 625 m, the spillway level, and exceeds that only while
    spilling (maximum 2294 GL at 626.6 m). Its lowest value, 329 GL at
    573.2 m, was on 11 May 2024. No Kelduárlón series is supplied.
  * Test starts: 1600, 1800 and 1950 Mm3, close to the lowest (2024), median
    (2025) and highest (2017) 1 January volumes. Aim to end the year with at
    least the starting storage.
  * Test year: keep 2024 out of all estimation (training years 2015-2023)
    and run your policy on it from 1600 Mm3.

Things to bear in mind
  * Few years. About ten complete years are available. Bear this in mind
    when estimating monthly transition probabilities and when judging a
    95% annual reliability target. Where a transition-matrix row has no
    observations, the assignment says to use class probabilities from a
    normal distribution fitted to that month's inflow volumes in the
    training years.

Wind readings (follow-up question 1)
  Monthly "Efficiency while in operation [%]" values read from the bar labels
  of Figure 16 in Clausen, N.-E. and Giebel, G. (eds.), IceWind final
  scientific report (2017), DTU Wind Energy E-0153, PDF page 44:
  https://www.vedur.is/media/vedurstofan-utgafa-2017/IceWind-final-scientific-report-Oct-2017.pdf#page=44
  The bars describe Landsvirkjun's two 900 kW Búrfell turbines. "first" and
  "second" mark two January-starting blocks in chart order, not calendar
  years. The second block ends in October, so November and December have one
  reading each. Values are the rounded percentages printed on the chart.
